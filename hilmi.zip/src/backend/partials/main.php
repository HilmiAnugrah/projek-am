<main class="pt-20 overflow-hidden bg-body">
    <!-- program pilihan -->
    <?php require "src/backend/partials/card-program-pilihan.php"; ?>
    <!-- end program pilihan -->
    <!-- seputar pesantren -->
    <?php require "src/backend/partials/seputar-pesantren.php"; ?>
    <!-- menu category -->
    <?php require "src/backend/partials/menu-category.php"; ?>
    <!-- end seputar pesantren -->
    <!-- extracurricular -->
    <?php require "src/backend/partials/card-extracurricular.php"; ?>
    <!-- end extracurricular -->
    <?php require "src/backend/partials/card-berita.php"; ?>
    <!-- maps -->
    <?php require "src/backend/partials/maps.php";?>
</main>
