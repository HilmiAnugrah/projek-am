<section class="maps bg-white w-full  pt-10 pb-[6em]">
    <h2 class="font-bold text-center px-[5%] text-3xl sm:text-4xl  text-main-green ">
        Kunjungi Kami Sekarang
    </h2>
    <p class="text-base px-[5%] tracking-widest text-center md:text-xl lg:text-2xl mt-1 text-main-green">
    Jl. Arcamanik, Sindanglaya, Kec. Cimenyan, Kab. Bandung, Jawa Barat 40195
    </p>
    <iframe class="rounded-xl lg:w-[70%] w-[90%] h-[300px] sm:h-[450px] mx-auto my-4 sm:my-8" title="Jl. Arcamanik, Sindanglaya, Kec. Cimenyan, Kab. Bandung, Jawa Barat 40195" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3961.0001135748507!2d107.68234017487042!3d-6.890588267428023!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68dd713e76b2a7%3A0xfee7580a9351b376!2sPondok%20Pesantren%20Al-&#39;Ashr%20Al-Madani!5e0!3m2!1sid!2sid!4v1691390859476!5m2!1sid!2sid" style="border: 5px solid #F0F2F9;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</section>