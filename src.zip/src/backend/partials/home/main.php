<main class="pt-20 overflow-hidden bg-body">
    <!-- program pilihan -->
    <?php require "src/backend/partials/home/card-program-pilihan.php"; ?>
    <!-- end program pilihan -->
    <!-- seputar pesantren -->
    <?php require "src/backend/partials/home/seputar-pesantren.php"; ?>
    <!-- menu category -->
    <?php require "src/backend/partials/home/menu-category.php"; ?>
    <!-- end seputar pesantren -->
    <!-- extracurricular -->
    <?php require "src/backend/partials/home/card-extracurricular.php"; ?>
    <!-- end extracurricular -->
    <?php require "src/backend/partials/home/card-berita.php"; ?>
    <!-- maps -->
    <?php require "src/backend/partials/home/maps.php";?>
</main>
